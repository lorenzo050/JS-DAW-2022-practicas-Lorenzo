Realizar una página web, usando Sass, que incluya:
- 3 botones
- Nesting
- Variables globales y locales. Hacer uso de !default .
- Un selector, o más, placeholder
- La función calc()
- Una lista de elementos y alguna función que actúe sobre dicha
lista (length, index, join, append...).
- Un Mapa (Map) y usar este con las funciones propias de los
mapas.