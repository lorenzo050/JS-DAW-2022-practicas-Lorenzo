Sass. Ejercicio 2
Andrea, Dani y Gabi son tres users de nuestra web.
Andrea navega desde su portátil (1000px) y le gusta ver el fondo de su footer de
color verde claro, Dani prefiere hacerlo desde su tablet (800px) con un fondo de
footer naranja, mientras que Gabi lo hace con su smartphone (100px) y le
apasiona ver el fondo del footer en rojo. Usando Sass no tendrás problema en
conseguir que el color del fondo del footer se actualice según el tamaño del
navegador en pantalla. Incluye alguna característica más, en el footer, según el
"dispositivo" que emplee el usuario.
Incluye una variable con la palabra reservada "!default" que actualice la variable
con el mismo nombre que hemos definido antes.
Usando un bucle de Sass, hacer que conforme vamos incrementando el valor de
los encabezados (<h1>,<h2>...) se vea más oscuro y su texto más claro.
Usaremos una directiva @while para lo primero y una directiva @for, con
through, para lo segundo (se podría haber hecho todo en la misma, piensa
como).
Añade entre cada encabezado 2 botones.
